package main

import (
	"fmt"
	"math"
	"math/rand"
	"os"
	"runtime"
	"sync"
	"time"
)

const (
	width  = 100
	height = 100
	steps  = 500
)

type Animal struct {
	species string
	gender  string
	x       float64
	y       float64
	alive   bool
	id      int
}

type Stats struct {
	initialPopulations map[string]int
	finalPopulations   map[string]int
	reproductions      int
	predations         int
	executionTime      time.Duration
	totalAnimals       int
}

func main() {
	start := time.Now()
	
	// Paralel çalışma için CPU çekirdek sayısını kullan
	numCPU := runtime.NumCPU()
	runtime.GOMAXPROCS(numCPU)
	fmt.Printf("🚀 Simülasyon başlıyor - %d CPU çekirdeği kullanılıyor\n\n", numCPU)
	
	animals := initializeAnimals()
	stats := Stats{
		initialPopulations: make(map[string]int),
		finalPopulations:   make(map[string]int),
	}
	
	// Başlangıç popülasyonlarını kaydet
	for _, animal := range animals {
		if animal.alive {
			stats.initialPopulations[animal.species]++
			stats.totalAnimals++
		}
	}
	
	// İlerleme çubuğu için kanal
	progress := make(chan int, 10)
	go showProgressBar(progress)
	
	// Simülasyonu çalıştır
	animals = runSimulation(animals, progress, &stats)
	
	// İstatistikleri hesapla
	stats.executionTime = time.Since(start)
	for _, animal := range animals {
		if animal.alive {
			stats.finalPopulations[animal.species]++
		}
	}
	
	// Sonuçları göster
	printResults(animals, stats)
	saveResultsToFile(stats)
}

func initializeAnimals() []*Animal {
	rand.Seed(time.Now().UnixNano())
	animals := []*Animal{}
	idCounter := 1

	// Koyunlar
	for i := 0; i < 15; i++ {
		animals = append(animals, &Animal{"sheep", "male", rand.Float64() * width, rand.Float64() * height, true, idCounter})
		idCounter++
	}
	for i := 0; i < 15; i++ {
		animals = append(animals, &Animal{"sheep", "female", rand.Float64() * width, rand.Float64() * height, true, idCounter})
		idCounter++
	}

	// İnekler
	for i := 0; i < 5; i++ {
		animals = append(animals, &Animal{"cow", "male", rand.Float64() * width, rand.Float64() * height, true, idCounter})
		idCounter++
	}
	for i := 0; i < 5; i++ {
		animals = append(animals, &Animal{"cow", "female", rand.Float64() * width, rand.Float64() * height, true, idCounter})
		idCounter++
	}

	// Tavuk ve horozlar
	for i := 0; i < 10; i++ {
		animals = append(animals, &Animal{"chicken", "female", rand.Float64() * width, rand.Float64() * height, true, idCounter})
		idCounter++
	}
	for i := 0; i < 10; i++ {
		animals = append(animals, &Animal{"rooster", "male", rand.Float64() * width, rand.Float64() * height, true, idCounter})
		idCounter++
	}

	// Kurtlar
	for i := 0; i < 5; i++ {
		animals = append(animals, &Animal{"wolf", "male", rand.Float64() * width, rand.Float64() * height, true, idCounter})
		idCounter++
	}
	for i := 0; i < 5; i++ {
		animals = append(animals, &Animal{"wolf", "female", rand.Float64() * width, rand.Float64() * height, true, idCounter})
		idCounter++
	}

	// Aslanlar
	for i := 0; i < 4; i++ {
		animals = append(animals, &Animal{"lion", "male", rand.Float64() * width, rand.Float64() * height, true, idCounter})
		idCounter++
	}
	for i := 0; i < 4; i++ {
		animals = append(animals, &Animal{"lion", "female", rand.Float64() * width, rand.Float64() * height, true, idCounter})
		idCounter++
	}

	// Avcı
	animals = append(animals, &Animal{"hunter", "none", rand.Float64() * width, rand.Float64() * height, true, idCounter})

	return animals
}

func runSimulation(animals []*Animal, progress chan<- int, stats *Stats) []*Animal {
	var wg sync.WaitGroup
	semaphore := make(chan struct{}, runtime.NumCPU()) // Eşzamanlılık semaforu

	for step := 0; step < steps; step++ {
		// İlerlemeyi güncelle
		if step%10 == 0 {
			progress <- step * 100 / steps
		}

		// Hareket - Paralel
		wg.Add(len(animals))
		for _, animal := range animals {
			semaphore <- struct{}{}
			go func(a *Animal) {
				defer wg.Done()
				if a.alive {
					moveAnimal(a)
				}
				<-semaphore
			}(animal)
		}
		wg.Wait()

		// Üreme
		newAnimals := reproductionPhase(animals, stats)
		animals = append(animals, newAnimals...)

		// Avlanma
		predationPhase(animals, stats)
	}
	close(progress)
	return animals
}

func moveAnimal(a *Animal) {
	stepSize := 1.0
	switch a.species {
	case "sheep", "cow":
		stepSize = 2
	case "wolf":
		stepSize = 3
	case "lion":
		stepSize = 4
	case "chicken", "rooster", "hunter":
		stepSize = 1
	}

	angle := rand.Float64() * 2 * math.Pi
	dx := stepSize * math.Cos(angle)
	dy := stepSize * math.Sin(angle)

	a.x = math.Max(0, math.Min(width, a.x+dx))
	a.y = math.Max(0, math.Min(height, a.y+dy))
}

func reproductionPhase(animals []*Animal, stats *Stats) []*Animal {
	males := make(map[string][]*Animal)
	females := make(map[string][]*Animal)

	for _, animal := range animals {
		if !animal.alive || animal.species == "hunter" {
			continue
		}

		species := animal.species
		if species == "rooster" {
			species = "chicken"
		}

		if animal.gender == "male" {
			males[species] = append(males[species], animal)
		} else if animal.gender == "female" {
			females[species] = append(females[species], animal)
		}
	}

	newAnimals := []*Animal{}
	idCounter := len(animals) + 1

	for species, femaleList := range females {
		maleList := males[species]
		if len(maleList) == 0 {
			continue
		}
		
		// Karıştırma
		rand.Shuffle(len(femaleList), func(i, j int) {
			femaleList[i], femaleList[j] = femaleList[j], femaleList[i]
		})
		rand.Shuffle(len(maleList), func(i, j int) {
			maleList[i], maleList[j] = maleList[j], maleList[i]
		})

		for _, female := range femaleList {
			if !female.alive {
				continue
			}

			for _, male := range maleList {
				if !male.alive {
					continue
				}

				if distance(female, male) <= 3 {
					newGender := "male"
					if rand.Float64() > 0.5 {
						newGender = "female"
					}

					newSpecies := species
					if species == "chicken" {
						if newGender == "female" {
							newSpecies = "chicken"
						} else {
							newSpecies = "rooster"
						}
					}

					x := (female.x + male.x) / 2
					y := (female.y + male.y) / 2
					newAnimals = append(newAnimals, &Animal{
						species: newSpecies,
						gender:  newGender,
						x:       x,
						y:       y,
						alive:   true,
						id:      idCounter,
					})
					idCounter++
					stats.reproductions++
					break
				}
			}
		}
	}
	return newAnimals
}

func predationPhase(animals []*Animal, stats *Stats) {
	// Avlanma - Kurtlar
	for _, wolf := range animals {
		if !wolf.alive || wolf.species != "wolf" {
			continue
		}

		for _, prey := range animals {
			if !prey.alive || prey == wolf {
				continue
			}

			if (prey.species == "sheep" || prey.species == "chicken" || prey.species == "rooster") &&
				distance(wolf, prey) <= 4 {
				prey.alive = false
				stats.predations++
			}
		}
	}

	// Avlanma - Aslanlar
	for _, lion := range animals {
		if !lion.alive || lion.species != "lion" {
			continue
		}

		for _, prey := range animals {
			if !prey.alive || prey == lion {
				continue
			}

			if (prey.species == "cow" || prey.species == "sheep") &&
				distance(lion, prey) <= 5 {
				prey.alive = false
				stats.predations++
			}
		}
	}

	// Avlanma - Avcı
	var hunter *Animal
	for _, animal := range animals {
		if animal.alive && animal.species == "hunter" {
			hunter = animal
			break
		}
	}

	if hunter != nil {
		for _, prey := range animals {
			if !prey.alive || prey == hunter || prey.species == "hunter" {
				continue
			}

			if distance(hunter, prey) <= 8 {
				prey.alive = false
				stats.predations++
			}
		}
	}
}

func distance(a, b *Animal) float64 {
	dx := a.x - b.x
	dy := a.y - b.y
	return math.Sqrt(dx*dx + dy*dy)
}

func showProgressBar(progress <-chan int) {
	fmt.Println("Simülasyon ilerlemesi:")
	for p := range progress {
		fmt.Printf("[")
		pos := int(float64(50) * float64(p) / 100.0)
		for i := 0; i < 50; i++ {
			if i < pos {
				fmt.Printf("=")
			} else if i == pos {
				fmt.Printf(">")
			} else {
				fmt.Printf(" ")
			}
		}
		fmt.Printf("] %d%%\r", p)
	}
	fmt.Println("\n✅ Simülasyon tamamlandı!")
}

func printResults(animals []*Animal, stats Stats) {
	fmt.Println("\n📊 === Hayvanat Bahçesi Simülasyonu Sonuçları ===")
	fmt.Printf("⏱️  Toplam simülasyon süresi: %v\n", stats.executionTime)
	fmt.Printf("🐣 Toplam üreme olayları: %d\n", stats.reproductions)
	fmt.Printf("🐺 Toplam avlanma olayları: %d\n", stats.predations)
	
	totalFinal := 0
	for _, count := range stats.finalPopulations {
		totalFinal += count
	}
	fmt.Printf("🐾 Toplam hayvan sayısı: Başlangıç: %d, Son: %d\n", 
		stats.totalAnimals, totalFinal)
	
	fmt.Println("\n📈 Başlangıç Popülasyonları:")
	fmt.Printf("🐑 Koyun: %d\n", stats.initialPopulations["sheep"])
	fmt.Printf("🐄 İnek: %d\n", stats.initialPopulations["cow"])
	fmt.Printf("🐔 Tavuk: %d\n", stats.initialPopulations["chicken"])
	fmt.Printf("🐓 Horoz: %d\n", stats.initialPopulations["rooster"])
	fmt.Printf("🐺 Kurt: %d\n", stats.initialPopulations["wolf"])
	fmt.Printf("🦁 Aslan: %d\n", stats.initialPopulations["lion"])
	fmt.Printf("🎯 Avcı: %d\n", stats.initialPopulations["hunter"])
	
	fmt.Println("\n📉 Son Popülasyonlar:")
	fmt.Printf("🐑 Koyun: %d\n", stats.finalPopulations["sheep"])
	fmt.Printf("🐄 İnek: %d\n", stats.finalPopulations["cow"])
	fmt.Printf("🐔 Tavuk: %d\n", stats.finalPopulations["chicken"])
	fmt.Printf("🐓 Horoz: %d\n", stats.finalPopulations["rooster"])
	fmt.Printf("🐺 Kurt: %d\n", stats.finalPopulations["wolf"])
	fmt.Printf("🦁 Aslan: %d\n", stats.finalPopulations["lion"])
	fmt.Printf("🎯 Avcı: %d\n", stats.finalPopulations["hunter"])
	
	// Popülasyon değişim oranları
	fmt.Println("\n📊 Popülasyon Değişimleri:")
	printChange("Koyun", stats.initialPopulations["sheep"], stats.finalPopulations["sheep"])
	printChange("İnek", stats.initialPopulations["cow"], stats.finalPopulations["cow"])
	printChange("Tavuk", stats.initialPopulations["chicken"], stats.finalPopulations["chicken"])
	printChange("Horoz", stats.initialPopulations["rooster"], stats.finalPopulations["rooster"])
	printChange("Kurt", stats.initialPopulations["wolf"], stats.finalPopulations["wolf"])
	printChange("Aslan", stats.initialPopulations["lion"], stats.finalPopulations["lion"])
	printChange("Avcı", stats.initialPopulations["hunter"], stats.finalPopulations["hunter"])
}

func printChange(species string, initial, final int) {
	change := final - initial
	percent := 0.0
	if initial > 0 {
		percent = float64(change) / float64(initial) * 100
	}
	
	arrow := "▲"
	colorStart := ""
	colorEnd := ""
	
	if change < 0 {
		arrow = "▼"
		colorStart = "\033[31m"
		colorEnd = "\033[0m"
	} else if change > 0 {
		colorStart = "\033[32m"
		colorEnd = "\033[0m"
	}
	
	fmt.Printf("%s: %d → %s%d%s %s (%s%s%d (%.2f%%)%s)\n", 
		species, initial, colorStart, final, colorEnd, arrow,
		colorStart, arrow, abs(change), math.Abs(percent), colorEnd)
}

func abs(n int) int {
	if n < 0 {
		return -n
	}
	return n
}

func saveResultsToFile(stats Stats) {
	file, err := os.Create("simulasyon_sonuclari.txt")
	if err != nil {
		fmt.Println("❌ Dosya oluşturma hatası:", err)
		return
	}
	defer file.Close()

	file.WriteString("=== Hayvanat Bahçesi Simülasyonu Sonuçları ===\n\n")
	file.WriteString(fmt.Sprintf("Toplam simülasyon süresi: %v\n", stats.executionTime))
	file.WriteString(fmt.Sprintf("Toplam üreme olayları: %d\n", stats.reproductions))
	file.WriteString(fmt.Sprintf("Toplam avlanma olayları: %d\n", stats.predations))
	
	totalFinal := stats.finalPopulations["sheep"] + stats.finalPopulations["cow"] +
		stats.finalPopulations["chicken"] + stats.finalPopulations["rooster"] +
		stats.finalPopulations["wolf"] + stats.finalPopulations["lion"] + stats.finalPopulations["hunter"]
	
	file.WriteString(fmt.Sprintf("Toplam hayvan sayısı: Başlangıç: %d, Son: %d\n\n", 
		stats.totalAnimals, totalFinal))
	
	file.WriteString("Başlangıç Popülasyonları:\n")
	file.WriteString(fmt.Sprintf("Koyun: %d\n", stats.initialPopulations["sheep"]))
	file.WriteString(fmt.Sprintf("İnek: %d\n", stats.initialPopulations["cow"]))
	file.WriteString(fmt.Sprintf("Tavuk: %d\n", stats.initialPopulations["chicken"]))
	file.WriteString(fmt.Sprintf("Horoz: %d\n", stats.initialPopulations["rooster"]))
	file.WriteString(fmt.Sprintf("Kurt: %d\n", stats.initialPopulations["wolf"]))
	file.WriteString(fmt.Sprintf("Aslan: %d\n", stats.initialPopulations["lion"]))
	file.WriteString(fmt.Sprintf("Avcı: %d\n\n", stats.initialPopulations["hunter"]))
	
	file.WriteString("Son Popülasyonlar:\n")
	file.WriteString(fmt.Sprintf("Koyun: %d\n", stats.finalPopulations["sheep"]))
	file.WriteString(fmt.Sprintf("İnek: %d\n", stats.finalPopulations["cow"]))
	file.WriteString(fmt.Sprintf("Tavuk: %d\n", stats.finalPopulations["chicken"]))
	file.WriteString(fmt.Sprintf("Horoz: %d\n", stats.finalPopulations["rooster"]))
	file.WriteString(fmt.Sprintf("Kurt: %d\n", stats.finalPopulations["wolf"]))
	file.WriteString(fmt.Sprintf("Aslan: %d\n", stats.finalPopulations["lion"]))
	file.WriteString(fmt.Sprintf("Avcı: %d\n", stats.finalPopulations["hunter"]))
	
	fmt.Println("\n💾 Sonuçlar 'simulasyon_sonuclari.txt' dosyasına kaydedildi.")
}